# TraceX public saved-evidence replay

Run `python -m scripts.public_replay` here with Python 3.10+. Only the standard library is needed.

This verifies saved-artifact hashes, denominators and quotation spans. It does not rerun models, the full detector experiment or a human study. The saved source/citation examples are fictional integration data; the historical counts retain their original scope. No API credit is used.

Full source: https://github.com/rahulx2001/TraceX
